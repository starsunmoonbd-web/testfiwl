# Premium Recorder v7

- Fixed ReplyKeyboard tuple/list crash.
- Bangladesh time, 12-hour scheduling.
- M3U8/HLS recording directly to MP4 with start notification.
- HLS master playlist quality buttons when variants are available.
- SQLite users/jobs/settings database with safe parameter binding.
- Admin-only button panel: Stats, Users, Jobs, Disk, Broadcast, Set Log, Maintenance, Clear Jobs, Ban/Unban, Stop/Retry, Restart.
- User custom log destination.
- Google credentials.json upload and Drive integration for configured credentials.
- Telegram video delivery when file is within the configured Bot API upload limit.
- Optional Local Bot API Server support for large files.

## Install
```bash
unzip premium_recorder_v7.zip
cd premium_recorder_v7
./setup.sh
./run.sh
```

The requested bot token is embedded in `config.py`; no `.env` editing is required.

## Record
`/record 2:30 PM-3:00 PM https://example.com/index.m3u8`

If the URL is an HLS master playlist, the bot offers available quality variants.

## Large files
Telegram's official hosted Bot API currently accepts uploads up to 50 MB. A Local Bot API Server supports uploads up to 2000 MB. A 2–3 GB recording therefore needs a Local Bot API Server and/or Google Drive; the bot does not falsely claim that the hosted Bot API can send 3 GB files.
