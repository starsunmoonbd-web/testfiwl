from dataclasses import dataclass
from pathlib import Path
import os

BASE = Path(__file__).resolve().parent
TOKEN_FILE = BASE / 'tokens' / 'bot_token.txt'
# Requested token is embedded so .env is not required on mobile.
BOT_TOKEN = '8946590257:AAF0hadTpkoafEGXjGvFAKihkMK6v34LYgw'
ADMIN_IDS = (8665709994,)

@dataclass(frozen=True)
class Settings:
    bot_token: str = BOT_TOKEN
    admin_ids: tuple[int, ...] = ADMIN_IDS
    timezone: str = 'Asia/Dhaka'
    db_path: Path = BASE / 'data' / 'bot.db'
    record_dir: Path = BASE / 'recordings'
    drive_dir: Path = BASE / 'tokens' / 'drive'
    max_record_minutes: int = 360
    local_bot_api_base_url: str = os.getenv('LOCAL_BOT_API_BASE_URL', '').strip()
    telegram_cloud_limit_mb: int = 50
    telegram_local_limit_mb: int = 2000

    @property
    def use_local_bot_api(self):
        return bool(self.local_bot_api_base_url)

    @property
    def telegram_upload_mb(self):
        return self.telegram_local_limit_mb if self.use_local_bot_api else self.telegram_cloud_limit_mb

settings = Settings()
for p in (settings.db_path.parent, settings.record_dir, settings.drive_dir, TOKEN_FILE.parent):
    p.mkdir(parents=True, exist_ok=True)
