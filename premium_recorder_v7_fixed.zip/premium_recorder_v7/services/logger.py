from database.db import get_setting, user_log

async def send_log(app,text,uid=None):
    ids=[]
    admin=get_setting('admin_log_chat_id')
    if admin:
        try: ids.append(int(admin))
        except ValueError: pass
    if uid:
        ch=user_log(uid)
        if ch and ch not in ids: ids.append(ch)
    for chat in ids:
        try: await app.bot.send_message(chat_id=chat,text=text)
        except Exception: pass
