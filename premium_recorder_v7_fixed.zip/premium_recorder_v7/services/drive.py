from pathlib import Path
import json
from config import settings
from database.db import save_drive_credentials,get_drive_credentials,save_drive_token,get_drive_token
SCOPES=['https://www.googleapis.com/auth/drive.file']

def save_credentials(uid,raw):
    data=json.loads(raw.decode('utf-8'))
    if 'installed' not in data and 'web' not in data and 'type' not in data:
        raise ValueError('Invalid credentials.json')
    p=settings.drive_dir/f'credentials_{uid}.json'; p.write_bytes(raw); save_drive_credentials(uid,p); return p

def credentials_present(uid):
    p=get_drive_credentials(uid); return bool(p and Path(p).exists())

def service_account_upload(uid,path):
    p=get_drive_credentials(uid)
    if not p: raise RuntimeError('credentials.json নেই')
    from google.oauth2 import service_account
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    data=json.loads(Path(p).read_text())
    if data.get('type')!='service_account': raise RuntimeError('OAuth client credentials require user consent; use /drive for OAuth setup.')
    creds=service_account.Credentials.from_service_account_file(str(p),scopes=SCOPES)
    svc=build('drive','v3',credentials=creds,cache_discovery=False)
    media=MediaFileUpload(str(path),resumable=True,chunksize=8*1024*1024)
    req=svc.files().create(body={'name':Path(path).name},media_body=media,fields='id,webViewLink')
    res=None
    while res is None: _,res=req.next_chunk()
    return res

def upload_file(uid,path):
    token=get_drive_token(uid)
    if token and Path(token).exists():
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
        creds=Credentials.from_authorized_user_file(str(token),SCOPES)
        svc=build('drive','v3',credentials=creds,cache_discovery=False)
        media=MediaFileUpload(str(path),resumable=True,chunksize=8*1024*1024)
        req=svc.files().create(body={'name':Path(path).name},media_body=media,fields='id,webViewLink')
        res=None
        while res is None: _,res=req.next_chunk()
        return res
    return service_account_upload(uid,path)
