import asyncio
from database.db import list_jobs
from services.recorder import run_job
tasks={}

def schedule(app,jid,notify):
    old=tasks.get(jid)
    if old and not old.done(): return old
    t=asyncio.create_task(run_job(app,jid,notify),name=f'record-{jid}'); tasks[jid]=t; return t

def restore(app,notify):
    for j in list_jobs():
        if j['status']=='scheduled': schedule(app,j['id'],notify)
