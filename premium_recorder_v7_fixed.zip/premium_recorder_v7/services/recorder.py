import asyncio, shutil
from pathlib import Path
from datetime import datetime
from database.db import get_job, update_job
from config import settings
running={}

async def tell(app,chat,text,**kw):
    try: await app.bot.send_message(chat_id=chat,text=text,**kw)
    except Exception: pass

async def send_video_or_fallback(app,job,path):
    size=path.stat().st_size
    limit=settings.telegram_upload_mb*1024*1024
    if size>limit: return False
    with path.open('rb') as f:
        await app.bot.send_video(chat_id=job['chat_id'],video=f,caption=f'🎬 {job["filename"]}\n🆔 {job["id"]}',supports_streaming=True,read_timeout=3600,write_timeout=3600,connect_timeout=60,pool_timeout=60)
    return True

def ffmpeg_cmd(url,out,dur):
    return ['ffmpeg','-y','-nostdin','-hide_banner','-loglevel','warning','-user_agent','Mozilla/5.0','-rw_timeout','30000000','-reconnect','1','-reconnect_streamed','1','-reconnect_at_eof','1','-reconnect_delay_max','10','-i',url,'-t',str(dur),'-map','0:v:0?','-map','0:a:0?','-c','copy','-movflags','+faststart',str(out)]

async def send_local_parts(app, job, path):
    if not settings.use_local_bot_api: return False
    if path.stat().st_size <= 1900*1024*1024: return False
    # Make valid MP4 segments below the Local Bot API 2000 MB limit.
    dur_cmd=['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)]
    try:
        p=await asyncio.create_subprocess_exec(*dur_cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL)
        out,_=await p.communicate(); duration=float(out.decode().strip())
    except Exception:
        return False
    target=1700*1024*1024
    parts=max(2,int(path.stat().st_size/target)+1)
    seg_seconds=max(60,int(duration/parts)+30)
    pattern=path.with_name(path.stem+'_part%02d.mp4')
    cmd=['ffmpeg','-y','-hide_banner','-loglevel','warning','-i',str(path),'-map','0','-c','copy','-f','segment','-segment_time',str(seg_seconds),'-reset_timestamps','1',str(pattern)]
    p=await asyncio.create_subprocess_exec(*cmd,stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.PIPE)
    err=await p.stderr.read(); rc=await p.wait()
    if rc!=0: raise RuntimeError(err.decode(errors='ignore')[-1200:] or 'MP4 splitting failed')
    files=sorted(path.parent.glob(path.stem+'_part*.mp4'))
    try:
        for i,part in enumerate(files,1):
            if part.stat().st_size >= 2000*1024*1024: raise RuntimeError('Generated Telegram part is too large')
            with part.open('rb') as f:
                await app.bot.send_video(chat_id=job['chat_id'],video=f,caption=f'🎬 {job["filename"]} — Part {i}/{len(files)}\n🆔 {job["id"]}',supports_streaming=True,read_timeout=3600,write_timeout=3600,connect_timeout=60,pool_timeout=60)
    finally:
        for part in files:
            try: part.unlink()
            except FileNotFoundError: pass
    return True

async def run_job(app,jid,notify):
    job=get_job(jid)
    if not job:return
    from utils.time import now
    delay=(datetime.fromisoformat(job['start_time'])-now()).total_seconds()
    if delay>0: await asyncio.sleep(delay)
    job=get_job(jid)
    if not job or job['status']!='scheduled': return
    dur=max(1,int((datetime.fromisoformat(job['end_time'])-now()).total_seconds()))
    dur=min(dur,settings.max_record_minutes*60)
    if not shutil.which('ffmpeg'):
        update_job(jid,status='failed',error='FFmpeg not installed'); await tell(app,job['chat_id'],f'❌ Recording failed\n🆔 {jid}\nFFmpeg not installed'); return
    out=settings.record_dir/f'{jid}_{job["filename"]}.mp4'
    try: out.unlink()
    except FileNotFoundError: pass
    update_job(jid,status='recording',error=None)
    started=f'🔴 Recording started\n🆔 {jid}\n🎞️ Quality: {job.get("quality") or "Original"}\n⏱️ {dur//60}m {dur%60}s'
    await tell(app,job['chat_id'],started)
    try:
        proc=await asyncio.create_subprocess_exec(*ffmpeg_cmd(job['url'],out,dur),stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.PIPE)
        running[jid]=proc
        stderr=await proc.stderr.read(); rc=await proc.wait()
    except Exception as e:
        running.pop(jid,None); update_job(jid,status='failed',error=str(e)); await tell(app,job['chat_id'],f'❌ Recording error\n🆔 {jid}\n{e}'); return
    running.pop(jid,None)
    if get_job(jid)['status']=='cancelled':
        try: out.unlink()
        except FileNotFoundError: pass
        return
    if rc!=0 or not out.exists() or out.stat().st_size==0:
        err=stderr.decode(errors='ignore').strip()[-1800:] or f'ffmpeg exit {rc}'
        update_job(jid,status='failed',error=err); await tell(app,job['chat_id'],f'❌ Recording failed\n🆔 {jid}\n{err}'); return
    update_job(jid,status='uploading',output_file=str(out))
    await tell(app,job['chat_id'],f'✅ Recording finished\n🆔 {jid}\n📦 {out.stat().st_size/(1024*1024):.1f} MB\n📤 Uploading MP4...')
    try:
        ok=await send_video_or_fallback(app,job,out)
        if not ok:
            if await send_local_parts(app,job,out):
                ok=True
            else:
                from services.drive import credentials_present, upload_file
                if credentials_present(job['user_id']):
                    res=await asyncio.to_thread(upload_file,job['user_id'],out)
                    link=res.get('webViewLink') or f'https://drive.google.com/file/d/{res["id"]}/view'
                    await tell(app,job['chat_id'],f'☁️ Telegram file limit exceeded. Google Drive upload complete:\n{link}')
                else:
                    raise RuntimeError(f'MP4 is {out.stat().st_size/(1024*1024):.1f} MB. Official Telegram Bot API upload limit is 50 MB. Configure Local Bot API Server for up to 2000 MB or connect Google Drive.')
        update_job(jid,status='completed',error=None)
        await tell(app,job['chat_id'],f'🎉 Recording delivered\n🆔 {jid}')
        try: out.unlink()
        except FileNotFoundError: pass
    except Exception as e:
        update_job(jid,status='failed',error=str(e)); await tell(app,job['chat_id'],f'❌ Upload failed\n🆔 {jid}\n{e}')

def stop_job(jid):
    p=running.get(jid)
    if p and p.returncode is None:
        p.terminate(); return True
    return False
