from urllib.request import Request, urlopen
from urllib.parse import urljoin
import re

def fetch(url):
    req=Request(url,headers={'User-Agent':'Mozilla/5.0'})
    with urlopen(req,timeout=15) as r: return r.read().decode('utf-8','replace')

def qualities(url):
    try: text=fetch(url)
    except Exception: return []
    if '#EXT-X-STREAM-INF' not in text: return []
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    out=[]
    for i,line in enumerate(lines):
        if line.startswith('#EXT-X-STREAM-INF:') and i+1<len(lines):
            attrs=line.split(':',1)[1]
            m=re.search(r'RESOLUTION=(\d+x\d+)',attrs)
            bw=re.search(r'BANDWIDTH=(\d+)',attrs)
            label=m.group(1) if m else (f'{int(bw.group(1))/1000:.0f} kbps' if bw else 'Variant')
            u=urljoin(url,lines[i+1])
            out.append((label,u))
    seen=set(); return [x for x in out if not (x[1] in seen or seen.add(x[1]))]
