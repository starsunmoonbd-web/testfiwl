import re

def safe_name(s):
    s=re.sub(r'[^A-Za-z0-9._-]+','_',s.strip())
    return (s[:80] or 'recording')
