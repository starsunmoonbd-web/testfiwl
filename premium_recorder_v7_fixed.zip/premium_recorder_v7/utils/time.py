from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from config import settings
TZ=ZoneInfo(settings.timezone)

def now(): return datetime.now(TZ)

def parse_clock(s):
    s=' '.join(s.strip().upper().split())
    for fmt in ('%I:%M %p','%I %p'):
        try: return datetime.strptime(s,fmt).time()
        except ValueError: pass
    raise ValueError('সময় 12-hour format-এ দিন, যেমন 2:30 PM')

def parse_window(a,b):
    n=now(); start=datetime.combine(n.date(),parse_clock(a),TZ); end=datetime.combine(n.date(),parse_clock(b),TZ)
    if start <= n: start += timedelta(days=1); end += timedelta(days=1)
    elif end <= start: end += timedelta(days=1)
    if (end-start).total_seconds() <= 0: raise ValueError('End time must be after start time')
    return start,end
