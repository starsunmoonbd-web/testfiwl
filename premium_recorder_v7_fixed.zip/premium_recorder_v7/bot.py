import logging
from telegram import Update
from telegram.ext import Application,CommandHandler,MessageHandler,CallbackQueryHandler,filters
from telegram.request import HTTPXRequest
from config import settings
from database.db import init_db,upsert_user,is_blocked
from handlers.user import start,time_cmd,help_cmd,record,jobs,status,cancel,stop,userlog_cmd,mylog,drive,drive_credentials_document,quality_callback,keyboard
from handlers.admin import admin_cmd,admin_callback,admin_text_action
from services.scheduler import restore
from services.logger import send_log

logging.basicConfig(level=logging.INFO,format='%(asctime)s | %(levelname)s | %(message)s')

async def post_init(app):
    init_db(); restore(app,lambda text,uid: send_log(app,text,uid)); logging.info('Premium Recorder v7 started | timezone=Asia/Dhaka')

async def start_cmd(update,ctx): await start(update,ctx)

async def text_router(update,ctx):
    if not update.message:return
    if await admin_text_action(update,ctx): return
    t=(update.message.text or '').strip()
    uid=update.effective_user.id
    if t=='👑 Admin Panel':
        if uid in settings.admin_ids: return await admin_cmd(update,ctx)
        return
    if t=='🎥 Record': return await update.message.reply_text('🎥 Send:\n/record 2:30 PM-3:00 PM https://example.com/index.m3u8 [name]')
    if t=='🕐 Time': return await time_cmd(update,ctx)
    if t=='📋 My Jobs': return await jobs(update,ctx)
    if t=='❌ Cancel Job': return await update.message.reply_text('❌ Use /cancel JOB_ID')
    if t=='☁️ Google Drive': return await drive(update,ctx)
    if t=='ℹ️ Help': return await help_cmd(update,ctx)

async def error_handler(update,ctx):
    logging.exception('Unhandled update error',exc_info=ctx.error)
    try:
        if update and update.effective_chat: await update.effective_chat.send_message('⚠️ Temporary error. Check bot logs.')
    except Exception: pass

def main():
    if not settings.bot_token or settings.bot_token.startswith('PUT_'): raise SystemExit('BOT_TOKEN missing')
    init_db()
    request=HTTPXRequest(connect_timeout=30,read_timeout=600,write_timeout=600,media_write_timeout=600,pool_timeout=30)
    b=Application.builder().token(settings.bot_token).request(request).post_init(post_init)
    if settings.local_bot_api_base_url: b=b.base_url(settings.local_bot_api_base_url)
    app=b.build()
    for cmd,fn in [('start',start_cmd),('time',time_cmd),('help',help_cmd),('record',record),('jobs',jobs),('status',status),('cancel',cancel),('stop',stop),('userlog',userlog_cmd),('mylog',mylog),('drive',drive),('admin',admin_cmd)]: app.add_handler(CommandHandler(cmd,fn))
    app.add_handler(CallbackQueryHandler(quality_callback,pattern=r'^qual:'))
    app.add_handler(CallbackQueryHandler(admin_callback,pattern=r'^adm:'))
    app.add_handler(MessageHandler(filters.Document.ALL,drive_credentials_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,text_router))
    app.add_error_handler(error_handler)
    app.run_polling(allowed_updates=Update.ALL_TYPES,close_loop=False)

if __name__=='__main__': main()
