#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
sudo apt-get update -y
sudo apt-get install -y ffmpeg python3-venv unzip
python3 -m venv venv
source venv/bin/activate
python -m pip install -U pip
pip install -r requirements.txt
mkdir -p data recordings tokens/drive
python3 -m py_compile bot.py config.py database/db.py handlers/user.py handlers/admin.py services/*.py utils/*.py
echo '✅ Premium Recorder v7 installed and syntax checked.'
echo 'Run: ./run.sh'
