import asyncio, os, sys, shutil
from telegram import InlineKeyboardButton,InlineKeyboardMarkup
from config import settings
from database.db import *
from services.recorder import stop_job
from services.scheduler import schedule
from services.logger import send_log

def ok(uid): return int(uid) in settings.admin_ids

def panel_markup():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton('📊 Stats',callback_data='adm:stats'),InlineKeyboardButton('👥 Users',callback_data='adm:users')],
        [InlineKeyboardButton('📋 Jobs',callback_data='adm:jobs'),InlineKeyboardButton('💾 Disk',callback_data='adm:disk')],
        [InlineKeyboardButton('📣 Broadcast',callback_data='adm:broadcast'),InlineKeyboardButton('📝 Set Log',callback_data='adm:setlog')],
        [InlineKeyboardButton('🔧 Maintenance',callback_data='adm:maintenance'),InlineKeyboardButton('🧹 Clear Jobs',callback_data='adm:clear')],
        [InlineKeyboardButton('🚫 Ban',callback_data='adm:ban'),InlineKeyboardButton('✅ Unban',callback_data='adm:unban')],
        [InlineKeyboardButton('⏹ Stop Job',callback_data='adm:stop'),InlineKeyboardButton('🔁 Retry',callback_data='adm:retry')],
        [InlineKeyboardButton('🔄 Restart',callback_data='adm:restart')]
    ])

async def admin_cmd(update,ctx):
    if ok(update.effective_user.id): await update.message.reply_text('👑 Premium Admin Control Center\n\nOnly authorized admin IDs can use these controls.',reply_markup=panel_markup())

async def admin_callback(update,ctx):
    q=update.callback_query; await q.answer()
    if not ok(update.effective_user.id): return await q.edit_message_text('🚫 Admin access only.')
    action=q.data.split(':',1)[1]
    if action=='stats':
        c=counts(); return await q.edit_message_text(f'📊 Statistics\n\n👥 Users: {user_count()}\n🟢 Active: {active_count()}\n📅 Scheduled: {c.get("scheduled",0)}\n🔴 Recording: {c.get("recording",0)}\n📤 Uploading: {c.get("uploading",0)}\n✅ Completed: {c.get("completed",0)}\n❌ Failed: {c.get("failed",0)}',reply_markup=panel_markup())
    if action=='users':
        us=list_users(); text='👥 Users\n\n'+('\n'.join(f'{u["user_id"]} · @{u["username"] or "-"} · {u["first_seen"][:10]}' for u in us[:40]) or 'No users')
        return await q.edit_message_text(text,reply_markup=panel_markup())
    if action=='jobs':
        js=list_jobs(None,30); text='📋 Recent Jobs\n\n'+('\n'.join(f'{j["id"]} · {j["status"]} · {j["user_id"]}' for j in js) or 'No jobs')
        return await q.edit_message_text(text,reply_markup=panel_markup())
    if action=='disk':
        t,u,f=shutil.disk_usage(settings.record_dir); return await q.edit_message_text(f'💾 Disk\n\nTotal: {t//2**30} GB\nUsed: {u//2**30} GB\nFree: {f//2**30} GB',reply_markup=panel_markup())
    if action in ('setlog','broadcast','ban','unban','stop','retry'):
        ctx.user_data['admin_action']=action
        prompts={'setlog':'📝 Send admin log chat/channel ID.','broadcast':'📣 Send the broadcast text.','ban':'🚫 Send user ID.','unban':'✅ Send user ID.','stop':'⏹ Send Job ID.','retry':'🔁 Send Job ID.'}
        return await q.edit_message_text(prompts[action],reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('⬅️ Back',callback_data='adm:back')]]))
    if action=='back': ctx.user_data.pop('admin_action',None); return await q.edit_message_text('👑 Premium Admin Control Center',reply_markup=panel_markup())
    if action=='clear': return await q.edit_message_text(f'🧹 Cleared {clear_finished()} finished jobs.',reply_markup=panel_markup())
    if action=='maintenance':
        new='off' if get_setting('maintenance','off')=='on' else 'on'; set_setting('maintenance',new); return await q.edit_message_text(f'🔧 Maintenance: {new.upper()}',reply_markup=panel_markup())
    if action=='restart':
        await q.edit_message_text('🔄 Restarting...'); await asyncio.sleep(1); os.execv(sys.executable,[sys.executable]+sys.argv)

async def admin_text_action(update,ctx):
    if not ok(update.effective_user.id): return False
    action=ctx.user_data.get('admin_action')
    if not action:return False
    text=(update.message.text or '').strip(); msg=''
    try:
        if action=='setlog': set_setting('admin_log_chat_id',int(text)); msg='✅ Admin log destination saved.'
        elif action=='broadcast':
            users=[u['user_id'] for u in list_users() if not u['blocked']]; sent=0
            for uid in users:
                try: await ctx.bot.send_message(uid,text); sent+=1
                except Exception: pass
            msg=f'📣 Broadcast complete: {sent}/{len(users)}'
        elif action in ('ban','unban'): set_block(int(text),action=='ban'); msg=f'✅ {action.title()}: {text}'
        elif action=='stop':
            j=get_job(text)
            if not j: msg='❌ Job not found.'
            else: stop_job(text); update_job(text,status='cancelled'); msg=f'⏹ Stopped: {text}'
        elif action=='retry':
            j=get_job(text)
            if not j: msg='❌ Job not found.'
            else: update_job(text,status='scheduled',error=None); schedule(ctx.application,text,lambda t,u: send_log(ctx.application,t,u)); msg=f'🔁 Retry queued: {text}'
    except (ValueError,TypeError): msg='❌ Invalid value.'
    ctx.user_data.pop('admin_action',None); await update.message.reply_text(msg,reply_markup=panel_markup()); return True
