import re
from uuid import uuid4
from telegram import ReplyKeyboardMarkup,InlineKeyboardButton,InlineKeyboardMarkup
from database.db import *
from config import settings
from utils.time import now,parse_window
from utils.text import safe_name
from services.scheduler import schedule
from services.hls import qualities

USER_KEYBOARD=[['🎥 Record','🕐 Time'],['📋 My Jobs','❌ Cancel Job'],['☁️ Google Drive','ℹ️ Help']]

def is_admin(uid): return int(uid) in settings.admin_ids

def keyboard(uid):
    rows=[list(x) for x in USER_KEYBOARD]
    if is_admin(uid): rows.append(['👑 Admin Panel'])
    return ReplyKeyboardMarkup(rows,resize_keyboard=True)

def notify_fn(app):
    from services.logger import send_log
    return lambda text,uid: send_log(app,text,uid)

async def start(update,ctx):
    uid=update.effective_user.id; upsert_user(uid,update.effective_user.username,now().isoformat())
    await update.message.reply_text(f'🤖 Premium M3U8 Recorder\n\n🕐 {now():%I:%M:%S %p}\n🌍 Asia/Dhaka\n\nSelect an option:',reply_markup=keyboard(uid))

async def time_cmd(update,ctx): await update.message.reply_text(f'🇧🇩 Bangladesh Time\n📅 {now():%d-%m-%Y}\n🕐 {now():%I:%M:%S %p}')

async def help_cmd(update,ctx):
    await update.message.reply_text('🎥 Record: /record 2:30 PM-3:00 PM URL\n\n🕐 /time\n📋 /jobs\n📌 /status JOB_ID\n❌ /cancel JOB_ID\n☁️ /drive\n📝 /userlog CHAT_ID\n\nSupports non-DRM HLS/M3U8 and MPD streams. HLS master links can show quality buttons before scheduling.')

async def record(update,ctx):
    uid=update.effective_user.id; upsert_user(uid,update.effective_user.username,now().isoformat())
    if is_blocked(uid): return await update.message.reply_text('🚫 You are blocked.')
    if get_setting('maintenance','off')=='on' and not is_admin(uid): return await update.message.reply_text('🔧 Maintenance mode is ON.')
    raw=update.message.text.partition(' ')[2].strip()
    m=re.match(r'^(.+?)\s*-\s*(.+?)\s+(https?://\S+?)(?:\s+(.+))?$',raw,re.I)
    if not m:return await update.message.reply_text('❌ Format:\n/record 2:30 PM-3:00 PM https://site/index.m3u8 [name]')
    a,b,url,name=m.group(1).strip(),m.group(2).strip(),m.group(3).strip(),(m.group(4) or 'recording').strip()
    try: start,end=parse_window(a,b)
    except Exception as e:return await update.message.reply_text(f'❌ {e}')
    if (end-start).total_seconds()>settings.max_record_minutes*60:return await update.message.reply_text(f'❌ Maximum duration: {settings.max_record_minutes} minutes.')
    variants=qualities(url) if '.m3u8' in url.lower() else []
    if variants:
        jid=uuid4().hex[:8]
        ctx.user_data[f'record:{jid}']={'a':start.isoformat(),'b':end.isoformat(),'url':url,'name':safe_name(name),'variants':variants}
        buttons=[[InlineKeyboardButton(f'🎞️ {label}',callback_data=f'qual:{jid}:{i}')] for i,(label,_) in enumerate(variants)]
        buttons.append([InlineKeyboardButton('📺 Original / Auto',callback_data=f'qual:{jid}:orig')])
        return await update.message.reply_text('🎚️ Quality নির্বাচন করুন:',reply_markup=InlineKeyboardMarkup(buttons))
    return await create_job(update,ctx,start,end,url,safe_name(name),'Original')

async def create_job(update,ctx,start,end,url,name,quality):
    jid=uuid4().hex[:8]
    job={'id':jid,'user_id':update.effective_user.id,'chat_id':update.effective_chat.id,'url':url,'filename':name,'start_time':start.isoformat(),'end_time':end.isoformat(),'status':'scheduled','output_file':None,'error':None,'quality':quality,'created_at':now().isoformat()}
    try:add_job(job); schedule(ctx.application,jid,notify_fn(ctx.application))
    except Exception as e:return await update.message.reply_text(f'❌ Database error: {e}')
    msg = f'✅ Recording scheduled\n🆔 {jid}\n🎚️ {quality}\n🕐 {start:%d-%m-%Y %I:%M %p} → {end:%I:%M %p}\n\n🔔 You will receive a start notification.'
    await update.effective_message.reply_text(msg)

async def quality_callback(update,ctx):
    q=update.callback_query; await q.answer()
    if not q.data.startswith('qual:'): return
    _,jid,choice=q.data.split(':',2); data=ctx.user_data.pop(f'record:{jid}',None)
    if not data:return await q.edit_message_text('⚠️ This selection expired. Please send /record again.')
    from datetime import datetime
    start=datetime.fromisoformat(data['a']); end=datetime.fromisoformat(data['b'])
    url=data['url']; quality='Original'
    if choice!='orig':
        idx=int(choice); quality,data_url=data['variants'][idx]; url=data_url
    await create_job(update,ctx,start,end,url,data['name'],quality)
    try: await q.edit_message_text(f'✅ Scheduled\n🆔 {jid}\n🎚️ {quality}')
    except Exception: pass

async def jobs(update,ctx):
    rs=list_jobs(update.effective_user.id,20)
    if not rs:return await update.message.reply_text('📭 No jobs.')
    await update.message.reply_text('\n'.join(f"🆔 {j['id']} · {j['status']} · {j.get('quality','Original')} · {j['start_time'][:16].replace('T',' ')}" for j in rs))

async def status(update,ctx):
    jid=ctx.args[0] if ctx.args else ''; j=get_job(jid)
    if not j or (j['user_id']!=update.effective_user.id and not is_admin(update.effective_user.id)):return await update.message.reply_text('❌ Job not found.')
    await update.message.reply_text(f"🆔 {jid}\n📌 {j['status']}\n🎚️ {j.get('quality','Original')}\n❗ {j['error'] or '—'}")

async def cancel(update,ctx):
    jid=ctx.args[0] if ctx.args else ''; j=get_job(jid)
    if not j or j['user_id']!=update.effective_user.id:return await update.message.reply_text('❌ Job not found.')
    if j['status'] not in ('scheduled','recording'):return await update.message.reply_text('⚠️ This job cannot be cancelled now.')
    if j['status']=='recording':
        from services.recorder import stop_job; stop_job(jid)
    update_job(jid,status='cancelled'); await update.message.reply_text(f'✅ Cancelled {jid}')

async def stop(update,ctx): return await cancel(update,ctx)

async def userlog_cmd(update,ctx):
    if not ctx.args:return await update.message.reply_text('Usage: /userlog -1001234567890')
    try: set_user_log(update.effective_user.id,int(ctx.args[0])); await update.message.reply_text('✅ Personal log destination saved.')
    except ValueError: await update.message.reply_text('❌ Invalid chat ID.')

async def mylog(update,ctx): await update.message.reply_text(f'📝 Your log chat: {user_log(update.effective_user.id) or "Not set"}')

async def drive(update,ctx):
    from services.drive import credentials_present,upload_file
    if not credentials_present(update.effective_user.id): return await update.message.reply_text('☁️ Send your Google credentials.json to this chat as a document first.\n\nService-account JSON can upload directly; OAuth client JSON needs an OAuth web redirect setup.')
    await update.message.reply_text('✅ credentials.json received. Large MP4 uploads can use Google Drive when the account is configured.')

async def drive_credentials_document(update,ctx):
    doc=update.message.document
    if not doc or doc.file_name.lower()!='credentials.json': return
    f=await doc.get_file(); raw=await f.download_as_bytearray()
    try:
        from services.drive import save_credentials
        save_credentials(update.effective_user.id,bytes(raw)); upsert_user(update.effective_user.id,update.effective_user.username,now().isoformat())
        await update.message.reply_text('✅ credentials.json saved securely for your account.')
    except Exception as e: await update.message.reply_text(f'❌ Invalid credentials.json: {e}')
