import sqlite3
from contextlib import contextmanager
from config import settings

@contextmanager
def db():
    c = sqlite3.connect(settings.db_path, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA busy_timeout=30000')
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback(); raise
    finally:
        c.close()

def init_db():
    with db() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS users(
            user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL, blocked INTEGER NOT NULL DEFAULT 0,
            user_log_chat_id INTEGER, drive_credentials TEXT, drive_token_file TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS jobs(
            id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, chat_id INTEGER NOT NULL,
            url TEXT NOT NULL, filename TEXT NOT NULL, start_time TEXT NOT NULL,
            end_time TEXT NOT NULL, status TEXT NOT NULL, output_file TEXT,
            error TEXT, quality TEXT DEFAULT 'Original', created_at TEXT NOT NULL)''')
        c.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)')
        for col, typ in [('quality','TEXT DEFAULT \'Original\''), ('error','TEXT')]:
            try: c.execute(f'ALTER TABLE jobs ADD COLUMN {col} {typ}')
            except sqlite3.OperationalError: pass
        for col, typ in [('user_log_chat_id','INTEGER'),('drive_credentials','TEXT'),('drive_token_file','TEXT')]:
            try: c.execute(f'ALTER TABLE users ADD COLUMN {col} {typ}')
            except sqlite3.OperationalError: pass

def upsert_user(uid, username, ts):
    with db() as c:
        c.execute('''INSERT INTO users(user_id,username,first_seen,last_seen) VALUES(?,?,?,?)
        ON CONFLICT(user_id) DO UPDATE SET username=excluded.username,last_seen=excluded.last_seen''', (int(uid), username or '', ts, ts))

def get_user(uid):
    with db() as c:
        r=c.execute('SELECT * FROM users WHERE user_id=?',(int(uid),)).fetchone()
        return dict(r) if r else None

def list_users():
    with db() as c: return [dict(r) for r in c.execute('SELECT * FROM users ORDER BY last_seen DESC')]

def set_block(uid, value):
    with db() as c:
        c.execute('''INSERT INTO users(user_id,username,first_seen,last_seen,blocked) VALUES(?,?,?,?,?)
        ON CONFLICT(user_id) DO UPDATE SET blocked=?''', (int(uid),'','','',int(bool(value)),int(bool(value))))

def is_blocked(uid):
    u=get_user(uid); return bool(u and u.get('blocked'))

def set_user_log(uid, chat_id):
    with db() as c: c.execute('UPDATE users SET user_log_chat_id=? WHERE user_id=?',(int(chat_id),int(uid)))

def user_log(uid):
    u=get_user(uid); return u.get('user_log_chat_id') if u else None

def add_job(job):
    keys=('id','user_id','chat_id','url','filename','start_time','end_time','status','output_file','error','quality','created_at')
    vals=tuple(job.get(k) for k in keys)
    with db() as c:
        c.execute('INSERT INTO jobs(id,user_id,chat_id,url,filename,start_time,end_time,status,output_file,error,quality,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', vals)

def get_job(jid):
    with db() as c:
        r=c.execute('SELECT * FROM jobs WHERE id=?',(jid,)).fetchone(); return dict(r) if r else None

def list_jobs(uid=None, limit=50):
    with db() as c:
        if uid is None: r=c.execute('SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?',(int(limit),)).fetchall()
        else: r=c.execute('SELECT * FROM jobs WHERE user_id=? ORDER BY created_at DESC LIMIT ?',(int(uid),int(limit))).fetchall()
        return [dict(x) for x in r]

def update_job(jid, **fields):
    allowed={'status','output_file','error','quality','url'}
    fields={k:v for k,v in fields.items() if k in allowed}
    if not fields:return
    q=', '.join(f'{k}=?' for k in fields)
    with db() as c: c.execute(f'UPDATE jobs SET {q} WHERE id=?', [*fields.values(), jid])

def clear_finished():
    with db() as c: return c.execute("DELETE FROM jobs WHERE status IN ('completed','failed','cancelled')").rowcount

def set_setting(k,v):
    with db() as c: c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,str(v)))

def get_setting(k,default=None):
    with db() as c:
        r=c.execute('SELECT value FROM settings WHERE key=?',(k,)).fetchone(); return r['value'] if r else default

def counts():
    with db() as c: return {r['status']:r['n'] for r in c.execute('SELECT status,COUNT(*) n FROM jobs GROUP BY status')}

def user_count():
    with db() as c: return c.execute('SELECT COUNT(*) FROM users').fetchone()[0]

def active_count():
    with db() as c: return c.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('scheduled','recording','uploading')").fetchone()[0]

def save_drive_credentials(uid,p):
    with db() as c: c.execute('UPDATE users SET drive_credentials=? WHERE user_id=?',(str(p),int(uid)))

def get_drive_credentials(uid):
    u=get_user(uid); return u.get('drive_credentials') if u else None

def save_drive_token(uid,p):
    with db() as c: c.execute('UPDATE users SET drive_token_file=? WHERE user_id=?',(str(p),int(uid)))

def get_drive_token(uid):
    u=get_user(uid); return u.get('drive_token_file') if u else None
