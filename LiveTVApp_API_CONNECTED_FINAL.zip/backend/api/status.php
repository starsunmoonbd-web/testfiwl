<?php
ini_set('display_errors', '0');
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

try {
    require_once __DIR__ . '/../config/config.php';
    $pdo = db();
    $tables = [];
    foreach (['admins','api_keys','channels'] as $table) {
        try {
            $pdo->query("SELECT 1 FROM `$table` LIMIT 1");
            $tables[$table] = true;
        } catch (Throwable $e) {
            $tables[$table] = false;
        }
    }
    $count = 0;
    if ($tables['channels']) {
        $count = (int)$pdo->query('SELECT COUNT(*) FROM channels WHERE active=1')->fetchColumn();
    }
    echo json_encode([
        'success'=>true,
        'php'=>PHP_VERSION,
        'database'=>true,
        'tables'=>$tables,
        'active_channels'=>$count
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'database'=>false,'message'=>'Database connection failed'], JSON_UNESCAPED_UNICODE);
}
