<?php
// LiveTV JSON API - robust version
ini_set('display_errors', '0');
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

function api_json(array $data, int $status = 200): void {
    http_response_code($status);
    while (ob_get_level() > 0) { @ob_end_clean(); }
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

// Convert uncaught PHP fatal errors into JSON so the Android app never receives an HTML error page.
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        while (ob_get_level() > 0) { @ob_end_clean(); }
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success'=>false, 'message'=>'PHP server error'], JSON_UNESCAPED_UNICODE);
    }
});

ob_start();

try {
    require_once __DIR__ . '/../config/config.php';

    $provided = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['api_key'] ?? '');
    $provided = trim((string)$provided);

    if ($provided === '') {
        api_json(['success'=>false, 'message'=>'API key required'], 401);
    }

    $pdo = db();
    $hash = hash('sha256', $provided);

    $s = $pdo->prepare('SELECT id FROM api_keys WHERE api_key_hash = ? AND active = 1 LIMIT 1');
    $s->execute([$hash]);
    if (!$s->fetch()) {
        api_json(['success'=>false, 'message'=>'Invalid API key'], 403);
    }

    $q = $pdo->query(
        'SELECT id, name, stream_url, logo_url, category
         FROM channels
         WHERE active = 1
         ORDER BY sort_order ASC, id ASC'
    );

    api_json([
        'success' => true,
        'data' => $q->fetchAll(PDO::FETCH_ASSOC),
        'message' => null
    ]);
} catch (Throwable $e) {
    // Never expose DB credentials or internal error details to clients.
    api_json(['success'=>false, 'message'=>'Server error'], 500);
}
