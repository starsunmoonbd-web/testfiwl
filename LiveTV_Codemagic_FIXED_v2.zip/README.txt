LiveTV Codemagic builder.
Place this ZIP in the repository root together with codemagic.yaml.
The builder extracts LiveTVApp.zip and builds the debug APK on Codemagic mac_mini_m2.
