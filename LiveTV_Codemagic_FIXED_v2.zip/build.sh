#!/usr/bin/env bash
set -Eeuo pipefail

rm -rf extracted
mkdir -p extracted
unzip -q "LiveTVApp.zip" -d extracted
cd extracted

export ANDROID_HOME="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [ -n "${ANDROID_SDK_ROOT:-}" ]; then
  echo "sdk.dir=$ANDROID_SDK_ROOT" > local.properties
fi

echo "=== Java ==="
java -version || true
echo "=== Gradle ==="
gradle --version

echo "=== Android project ==="
ls -la
ls -la app || true

test -n "${LIVE_TV_API_KEY:-}" || { echo "ERROR: LIVE_TV_API_KEY is missing in Codemagic."; exit 1; }

echo "=== Running Gradle ==="
gradle --no-daemon --stacktrace --info assembleDebug \
  -PLIVE_TV_BASE_URL="${LIVE_TV_BASE_URL:-https://sojib247.iceiy.com/}" \
  -PLIVE_TV_API_KEY="$LIVE_TV_API_KEY"
