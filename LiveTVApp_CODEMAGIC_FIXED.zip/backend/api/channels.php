<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../config/config.php';

$provided = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['api_key'] ?? '');
if (!$provided) {
    http_response_code(401);
    echo json_encode(['success'=>false,'message'=>'API key required']);
    exit;
}
$hash = hash('sha256', $provided);
$s = db()->prepare("SELECT id FROM api_keys WHERE api_key_hash=? AND active=1 LIMIT 1");
$s->execute([$hash]);
if (!$s->fetch()) {
    http_response_code(403);
    echo json_encode(['success'=>false,'message'=>'Invalid API key']);
    exit;
}

try {
    $q = db()->query("SELECT id,name,stream_url,logo_url,category FROM channels WHERE active=1 ORDER BY sort_order,id");
    echo json_encode(['success'=>true,'data'=>$q->fetchAll(),'message'=>null], JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Server error']);
}
