package com.example.livetv

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)

        if (ApiConfig.BASE_URL.isBlank() || !ApiConfig.BASE_URL.startsWith("https://")) {
            Toast.makeText(this, "Invalid API base URL", Toast.LENGTH_LONG).show()
            return
        }
        if (ApiConfig.API_KEY.isBlank()) {
            Toast.makeText(this, "API key is not configured", Toast.LENGTH_LONG).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.api.channels()
                val raw = (response.body()?.string() ?: response.errorBody()?.string().orEmpty())
                    .trimStart('\uFEFF', ' ', '\t', '\r', '\n')

                if (!response.isSuccessful) {
                    val serverMessage = extractServerMessage(raw)
                    Toast.makeText(
                        this@MainActivity,
                        "API HTTP ${response.code()}: ${serverMessage ?: "Request failed"}",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                if (raw.isBlank()) {
                    Toast.makeText(this@MainActivity, "API returned an empty response", Toast.LENGTH_LONG).show()
                    return@launch
                }

                if (!raw.startsWith("{")) {
                    Toast.makeText(
                        this@MainActivity,
                        "API returned non-JSON data. Check /api/channels.php",
                        Toast.LENGTH_LONG
                    ).show()
                    return@launch
                }

                val gson = GsonBuilder().setLenient().create()
                val type = object : TypeToken<ApiResponse<List<Channel>>>() {}.type
                val apiResponse: ApiResponse<List<Channel>> = gson.fromJson(raw, type)

                if (apiResponse.success && !apiResponse.data.isNullOrEmpty()) {
                    list.adapter = ChannelAdapter(apiResponse.data) { channel ->
                        startActivity(Intent(this@MainActivity, PlayerActivity::class.java).apply {
                            putExtra("name", channel.name)
                            putExtra("url", channel.stream_url)
                        })
                    }
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        apiResponse.message ?: "No channels available",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                Toast.makeText(
                    this@MainActivity,
                    "API error: ${e.message ?: "Connection failed"}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun extractServerMessage(raw: String): String? {
        return try {
            if (!raw.startsWith("{")) return null
            val gson = GsonBuilder().setLenient().create()
            val type = object : TypeToken<ApiResponse<Any>>() {}.type
            val result: ApiResponse<Any> = gson.fromJson(raw, type)
            result.message
        } catch (_: Exception) {
            null
        }
    }
}
