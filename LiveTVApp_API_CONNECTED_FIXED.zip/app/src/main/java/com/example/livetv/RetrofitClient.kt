package com.example.livetv

import retrofit2.Retrofit

object RetrofitClient {
    val api: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(ApiConfig.BASE_URL)
            .build()
            .create(ApiService::class.java)
    }
}
