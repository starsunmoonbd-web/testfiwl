import threading

from app.bot import create_application
from app.config import BOT_TOKEN, OAUTH_HOST, OAUTH_PORT
from app.handlers.youtube import oauth_app


def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN সেট করা হয়নি।")

    # OAuth callback web server. Put a reverse proxy (HTTPS) in front of this port.
    threading.Thread(
        target=lambda: oauth_app.run(host=OAUTH_HOST, port=OAUTH_PORT, debug=False, use_reloader=False),
        daemon=True,
    ).start()

    app = create_application()
    print("🤖 Telegram YouTube Uploader started...")
    app.run_polling()


if __name__ == "__main__":
    main()
