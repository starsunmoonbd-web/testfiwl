from app.config import ADMIN_ID


def is_admin(user_id: int) -> bool:
    return user_id == ADMIN_ID


def clean_title(title: str) -> str:
    title = title.strip()
    return title[:100] if title else "New Video"
