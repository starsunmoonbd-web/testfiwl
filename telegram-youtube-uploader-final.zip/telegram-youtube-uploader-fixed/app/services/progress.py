import time


class ProgressTracker:
    def __init__(self, message, prefix="Progress"):
        self.message = message
        self.prefix = prefix
        self.last_percent = -1
        self.last_update = 0

    async def update(self, percent: int):
        now = time.monotonic()
        if percent == self.last_percent:
            return
        if percent < 100 and now - self.last_update < 2:
            return
        self.last_percent = percent
        self.last_update = now
        bar_length = 20
        filled = int(bar_length * percent / 100)
        bar = "█" * filled + "░" * (bar_length - filled)
        try:
            await self.message.edit_text(f"📤 *{self.prefix}*\n\n`{bar}` {percent}%", parse_mode="Markdown")
        except Exception:
            pass
