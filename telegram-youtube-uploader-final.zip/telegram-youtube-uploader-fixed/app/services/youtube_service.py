from pathlib import Path
from threading import Lock

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

from app.config import CLIENT_SECRET_FILE, YOUTUBE_TOKEN_FILE, OAUTH_REDIRECT_URI

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
_flow_lock = Lock()
_pending_flow = None


def _new_flow():
    if not CLIENT_SECRET_FILE.exists():
        raise FileNotFoundError("credentials/client_secret.json পাওয়া যায়নি।")
    if not OAUTH_REDIRECT_URI:
        raise RuntimeError("OAUTH_REDIRECT_URI .env-এ সেট করা হয়নি।")
    if not OAUTH_REDIRECT_URI.startswith("https://"):
        raise RuntimeError("OAUTH_REDIRECT_URI অবশ্যই public HTTPS URL হতে হবে।")

    return Flow.from_client_secrets_file(
        str(CLIENT_SECRET_FILE),
        scopes=SCOPES,
        redirect_uri=OAUTH_REDIRECT_URI,
    )


def create_authorization_url():
    global _pending_flow
    with _flow_lock:
        flow = _new_flow()
        authorization_url, state = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            prompt="consent",
        )
        _pending_flow = (flow, state)
        return authorization_url


def complete_authorization(code: str, state: str):
    global _pending_flow
    with _flow_lock:
        if not _pending_flow:
            raise RuntimeError("কোনো pending YouTube connection পাওয়া যায়নি। আবার Connect YouTube চাপুন।")
        if not state:
            raise RuntimeError("OAuth state পাওয়া যায়নি। আবার Connect YouTube চাপুন।")

        flow, expected_state = _pending_flow
        if state != expected_state:
            _pending_flow = None
            raise RuntimeError("OAuth state mismatch। আবার Connect YouTube চাপুন।")
        if not code:
            raise RuntimeError("Authorization code পাওয়া যায়নি।")

        try:
            flow.fetch_token(code=code)
            credentials = flow.credentials
            YOUTUBE_TOKEN_FILE.write_text(credentials.to_json(), encoding="utf-8")
            return credentials
        finally:
            _pending_flow = None


def get_credentials():
    credentials = None

    if YOUTUBE_TOKEN_FILE.exists():
        credentials = Credentials.from_authorized_user_file(
            str(YOUTUBE_TOKEN_FILE), SCOPES
        )

    if credentials and credentials.expired and credentials.refresh_token:
        credentials.refresh(Request())
        YOUTUBE_TOKEN_FILE.write_text(credentials.to_json(), encoding="utf-8")

    if not credentials or not credentials.valid:
        raise RuntimeError("YouTube connected নেই। Telegram-এর Connect YouTube button চাপুন।")

    return credentials


def get_youtube():
    return build("youtube", "v3", credentials=get_credentials())


def get_channel():
    youtube = get_youtube()
    response = youtube.channels().list(part="snippet", mine=True).execute()
    items = response.get("items", [])
    if not items:
        return None
    channel = items[0]
    return {
        "id": channel["id"],
        "title": channel["snippet"]["title"],
        "url": f"https://www.youtube.com/channel/{channel['id']}",
    }


def upload_video(file_path: Path, title: str, description: str = "", privacy: str = "public", progress_callback=None):
    if privacy not in {"public", "unlisted", "private"}:
        raise ValueError("privacy অবশ্যই public, unlisted অথবা private হতে হবে।")

    youtube = get_youtube()
    body = {
        "snippet": {
            "title": title,
            "description": description,
            "categoryId": "22",
        },
        "status": {"privacyStatus": privacy},
    }

    media = MediaFileUpload(
        str(file_path), mimetype="video/*", resumable=True,
        chunksize=8 * 1024 * 1024,
    )
    request = youtube.videos().insert(
        part="snippet,status", body=body, media_body=media
    )

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status and progress_callback:
            progress_callback(int(status.progress() * 100))

    return response["id"]
