from pathlib import Path
from telegram import Bot


async def download_file(bot: Bot, file_id: str, destination: Path):
    telegram_file = await bot.get_file(file_id)
    destination.parent.mkdir(parents=True, exist_ok=True)
    await telegram_file.download_to_drive(custom_path=str(destination))
    return destination
