# Telegram YouTube Uploader

## VPS setup

1. Keep `.env` on the VPS and **never publish it**.
2. Put the Google OAuth client JSON at `credentials/client_secret.json`.
3. In Google Cloud, enable **YouTube Data API v3**.
4. Create an OAuth client suitable for a web redirect and add the exact redirect URI from `.env` (for example `https://YOUR_DOMAIN/oauth2callback`).
5. Point your HTTPS reverse proxy/domain to the bot's local OAuth server on port `8080`.
6. Install dependencies: `pip install -r requirements.txt`
7. Start: `python run.py`

## First connection

Press **Connect YouTube** in Telegram, open the generated Google authorization link, sign in to the YouTube account, grant permission, then return to Telegram.

The OAuth refresh token is stored in `data/youtube/token.json`. Do not publish it.

## Important

- The bot is restricted to `ADMIN_ID`.
- `client_secret.json`, `.env`, and `token.json` are intentionally excluded from Git via `.gitignore`.
- The OAuth callback requires a valid `state` value matching the pending connection.
- The current OAuth flow is intended for this single-admin bot. Do not expose the Connect function to multiple users without adding per-user OAuth sessions.

## Supplied Google OAuth credential

The supplied `client_secret.json` has `http://localhost` as its registered redirect URI. That credential can be used for a local OAuth callback, but it is **not sufficient for a public VPS callback**. For the VPS, create/use a Google OAuth Web application client, add your exact HTTPS `/oauth2callback` URI, replace `credentials/client_secret.json`, and set the same URI in `.env`.
