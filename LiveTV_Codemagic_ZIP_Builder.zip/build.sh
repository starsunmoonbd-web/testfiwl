#!/bin/bash
set -e
rm -rf extracted
mkdir extracted
unzip -q LiveTVApp.zip -d extracted
cd extracted
export ANDROID_HOME="$ANDROID_SDK_ROOT"
echo "sdk.dir=$ANDROID_SDK_ROOT" > local.properties
test -n "$LIVE_TV_API_KEY"
gradle --no-daemon --stacktrace assembleDebug -PLIVE_TV_BASE_URL="${LIVE_TV_BASE_URL:-https://sojib247.iceiy.com/}" -PLIVE_TV_API_KEY="$LIVE_TV_API_KEY"
