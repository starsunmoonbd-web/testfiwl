Codemagic Workflow Editor: add this ZIP as repo file, then use build command: bash build.sh. Set LIVE_TV_API_KEY as Secret environment variable.
