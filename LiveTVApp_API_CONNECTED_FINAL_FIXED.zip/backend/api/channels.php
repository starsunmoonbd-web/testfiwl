<?php
// API must always return JSON, never PHP warnings/notices mixed into the response.
ini_set('display_errors', '0');
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__.'/../config/config.php';

function json_out(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode(
        $payload,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}

$provided = $_SERVER['HTTP_X_API_KEY'] ?? ($_GET['api_key'] ?? '');
if (!$provided) {
    json_out(['success'=>false, 'message'=>'API key required'], 401);
}

try {
    $hash = hash('sha256', $provided);
    $s = db()->prepare("SELECT id FROM api_keys WHERE api_key_hash=? AND active=1 LIMIT 1");
    $s->execute([$hash]);
    if (!$s->fetch()) {
        json_out(['success'=>false, 'message'=>'Invalid API key'], 403);
    }

    $q = db()->query(
        "SELECT id,name,stream_url,logo_url,category
         FROM channels
         WHERE active=1
         ORDER BY sort_order,id"
    );

    json_out([
        'success'=>true,
        'data'=>$q->fetchAll(),
        'message'=>null
    ]);
} catch (Throwable $e) {
    json_out(['success'=>false, 'message'=>'Server error'], 500);
}
