<?php
session_start(); require_once __DIR__.'/../config/config.php';
if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $id=(int)($_POST['id']??0);
 if($id){$s=db()->prepare("UPDATE channels SET name=?,stream_url=?,logo_url=?,category=?,active=?,sort_order=? WHERE id=?");$s->execute([$_POST['name'],$_POST['stream_url'],$_POST['logo_url'],$_POST['category'],isset($_POST['active'])?1:0,(int)$_POST['sort_order'],$id]);}
 else {$s=db()->prepare("INSERT INTO channels(name,stream_url,logo_url,category,active,sort_order) VALUES(?,?,?,?,?,?)");$s->execute([$_POST['name'],$_POST['stream_url'],$_POST['logo_url'],$_POST['category'],1,(int)$_POST['sort_order']]);}
 header('Location: channels.php');exit;
}
if(isset($_GET['delete'])){db()->prepare("DELETE FROM channels WHERE id=?")->execute([(int)$_GET['delete']]);header('Location: channels.php');exit;}
$edit=null;if(isset($_GET['edit'])){$s=db()->prepare("SELECT * FROM channels WHERE id=?");$s->execute([(int)$_GET['edit']]);$edit=$s->fetch();}
$rows=db()->query("SELECT * FROM channels ORDER BY sort_order,id")->fetchAll();
?><!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Channels</title>
<style>body{font-family:Arial;background:#101010;color:#fff;padding:20px}input{width:100%;padding:11px;margin:5px 0;box-sizing:border-box}button{padding:11px}.card{background:#222;padding:14px;margin:10px 0;border-radius:8px}a{color:#8ecbff}</style>
<h1>Channels</h1><a href="dashboard.php">← Dashboard</a>
<div class="card"><h2><?= $edit?'Edit':'Add' ?> Channel</h2><form method="post"><input type="hidden" name="id" value="<?=htmlspecialchars($edit['id']??0)?>">
<input name="name" placeholder="Name" value="<?=htmlspecialchars($edit['name']??'')?>" required>
<input name="stream_url" placeholder="M3U8 URL" value="<?=htmlspecialchars($edit['stream_url']??'')?>" required>
<input name="logo_url" placeholder="Logo URL" value="<?=htmlspecialchars($edit['logo_url']??'')?>">
<input name="category" placeholder="Category" value="<?=htmlspecialchars($edit['category']??'')?>">
<input name="sort_order" type="number" value="<?=htmlspecialchars($edit['sort_order']??0)?>">
<?php if($edit): ?><label><input type="checkbox" name="active" <?=($edit['active']?'checked':'')?>> Active</label><?php endif; ?>
<button>Save</button></form></div>
<?php foreach($rows as $r): ?><div class="card"><b><?=htmlspecialchars($r['name'])?></b> — <?=htmlspecialchars($r['category']??'')?> — <?=($r['active']?'ON':'OFF')?><br><a href="?edit=<?=$r['id']?>">Edit</a> · <a href="?delete=<?=$r['id']?>" onclick="return confirm('Delete?')">Delete</a></div><?php endforeach; ?>
