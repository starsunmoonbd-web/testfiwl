<?php
session_start(); require_once __DIR__.'/../config/config.php';
if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}
$channels=(int)db()->query("SELECT COUNT(*) FROM channels")->fetchColumn();
$keys=(int)db()->query("SELECT COUNT(*) FROM api_keys WHERE active=1")->fetchColumn();
?>
<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard</title>
<style>body{font-family:Arial;background:#101010;color:#fff;padding:20px}a{display:block;background:#222;padding:16px;margin:10px 0;color:#fff;text-decoration:none;border-radius:8px}.stat{display:inline-block;background:#222;padding:18px;margin:5px;border-radius:8px}</style>
<h1>Dashboard</h1><div class="stat">Channels: <?=$channels?></div><div class="stat">Active API keys: <?=$keys?></div>
<a href="channels.php">📺 Manage Channels</a><a href="api_keys.php">🔑 API Keys</a><a href="logout.php">Logout</a>
