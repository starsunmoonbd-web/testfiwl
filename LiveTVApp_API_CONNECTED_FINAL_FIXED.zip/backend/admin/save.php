<?php
require_once __DIR__.'/../config/config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
if (($_POST['action'] ?? '') === 'add') {
    $s = db()->prepare("INSERT INTO channels(name,stream_url,logo_url,category,sort_order) VALUES(?,?,?,?,?)");
    $s->execute([
        trim($_POST['name'] ?? ''),
        trim($_POST['stream_url'] ?? ''),
        trim($_POST['logo_url'] ?? ''),
        trim($_POST['category'] ?? ''),
        (int)($_POST['sort_order'] ?? 0)
    ]);
}
header('Location: index.php');
