<?php
require_once __DIR__.'/../config/config.php';
$rows = db()->query("SELECT * FROM channels ORDER BY sort_order,id")->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Live TV Admin</title><style>
body{font-family:Arial;background:#101010;color:#fff;padding:20px} input,button{padding:10px;margin:4px;width:100%;box-sizing:border-box}
.card{background:#1d1d1d;padding:15px;margin-bottom:15px;border-radius:10px} table{width:100%;border-collapse:collapse}td,th{padding:8px;text-align:left}
</style></head><body><h1>Live TV Admin</h1>
<div class="card"><h2>Add channel</h2>
<form method="post" action="save.php">
<input name="name" placeholder="Channel name" required>
<input name="stream_url" placeholder="M3U8/HLS URL" required>
<input name="logo_url" placeholder="Logo URL">
<input name="category" placeholder="Category">
<input name="sort_order" type="number" value="0">
<button name="action" value="add">Add Channel</button></form></div>
<div class="card"><h2>Channels</h2><table><tr><th>Name</th><th>Category</th><th>Active</th></tr>
<?php foreach($rows as $r): ?><tr><td><?=htmlspecialchars($r['name'])?></td><td><?=htmlspecialchars($r['category']??'')?></td><td><?=($r['active']?'Yes':'No')?></td></tr><?php endforeach; ?>
</table></div></body></html>
