<?php
session_start(); require_once __DIR__.'/../config/config.php';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $s=db()->prepare("SELECT * FROM admins WHERE username=? LIMIT 1"); $s->execute([$_POST['username']??'']); $a=$s->fetch();
  if ($a && password_verify($_POST['password']??'', $a['password_hash'])) { session_regenerate_id(true); $_SESSION['admin_id']=$a['id']; header('Location: dashboard.php'); exit; }
  $err='Invalid login';
}
?><!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title>
<style>body{font-family:Arial;background:#101010;color:#fff;padding:25px;max-width:500px;margin:auto}input,button{width:100%;padding:12px;margin:7px 0;box-sizing:border-box}</style>
<h1>Live TV Admin</h1><p><?=htmlspecialchars($err??'')?></p><form method="post"><input name="username" placeholder="Username" required><input name="password" type="password" placeholder="Password" required><button>Login</button></form>
