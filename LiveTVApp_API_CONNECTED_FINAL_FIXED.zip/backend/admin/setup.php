<?php
require_once __DIR__.'/../config/config.php';
$count = (int)db()->query("SELECT COUNT(*) FROM admins")->fetchColumn();
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && $count===0) {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    if (strlen($u)>=3 && strlen($p)>=8) {
        $s=db()->prepare("INSERT INTO admins(username,password_hash) VALUES(?,?)");
        $s->execute([$u,password_hash($p,PASSWORD_DEFAULT)]);
        $msg='Admin created. Delete setup.php now, then login.';
        $count=1;
    } else $msg='Username must be 3+ chars and password 8+ chars.';
}
?>
<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Setup</title><style>body{font-family:Arial;background:#111;color:#fff;padding:25px;max-width:500px;margin:auto}input,button{width:100%;padding:12px;margin:7px 0;box-sizing:border-box}</style>
<h1>Live TV Admin Setup</h1>
<?php if($count>0): ?><p><?=htmlspecialchars($msg ?: 'Admin already exists. Delete setup.php.')?></p><?php else: ?>
<form method="post"><input name="username" placeholder="Admin username" required><input name="password" type="password" placeholder="Password (8+ chars)" required><button>Create Admin</button></form>
<?php endif; ?>
