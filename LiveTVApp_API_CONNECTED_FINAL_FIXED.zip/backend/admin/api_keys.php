<?php
session_start(); require_once __DIR__.'/../config/config.php';
if(empty($_SESSION['admin_id'])){header('Location: login.php');exit;}
$new=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=trim($_POST['name']??'API');
  $key='ltv_'.bin2hex(random_bytes(24));
  $s=db()->prepare("INSERT INTO api_keys(name,api_key_hash,api_key_prefix) VALUES(?,?,?)");
  $s->execute([$name,hash('sha256',$key),substr($key,0,12)]);
  $new=$key;
}
if(isset($_GET['disable'])){db()->prepare("UPDATE api_keys SET active=0 WHERE id=?")->execute([(int)$_GET['disable']]);header('Location: api_keys.php');exit;}
$rows=db()->query("SELECT * FROM api_keys ORDER BY id DESC")->fetchAll();
?><!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>API Keys</title>
<style>body{font-family:Arial;background:#101010;color:#fff;padding:20px}input,button{padding:12px;width:100%;box-sizing:border-box;margin:5px 0}.card{background:#222;padding:15px;margin:10px 0;border-radius:8px}.new{word-break:break-all;background:#333;padding:12px}</style>
<h1>API Keys</h1><a href="dashboard.php">← Dashboard</a>
<form method="post"><input name="name" placeholder="Key name, e.g. Android App" required><button>Generate API Key</button></form>
<?php if($new): ?><div class="card"><b>NEW API KEY — copy it now:</b><div class="new"><?=htmlspecialchars($new)?></div><small>The full key is never stored and cannot be shown again.</small></div><?php endif; ?>
<?php foreach($rows as $r): ?><div class="card"><b><?=htmlspecialchars($r['name'])?></b><br>Prefix: <?=htmlspecialchars($r['api_key_prefix'])?>...<br>Status: <?=($r['active']?'Active':'Disabled')?><?php if($r['active']): ?> · <a href="?disable=<?=$r['id']?>">Disable</a><?php endif; ?></div><?php endforeach; ?>
