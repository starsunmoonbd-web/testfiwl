package com.example.livetv

import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    // The backend accepts api_key as a GET parameter as well as X-API-Key.
    // Use the query parameter here because some shared/free hosts inject
    // an HTML security page when custom headers are used by non-browser clients.
    @GET("api/channels.php")
    suspend fun channels(
        @Query("api_key") apiKey: String = ApiConfig.API_KEY
    ): Response<ResponseBody>
}
