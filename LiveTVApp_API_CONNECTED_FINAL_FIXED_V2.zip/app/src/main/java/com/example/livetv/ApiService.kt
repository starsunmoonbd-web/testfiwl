package com.example.livetv

// API calls are performed directly by MainActivity using OkHttp.
// The backend endpoint is /api/channels.php?api_key=...
interface ApiService
