package com.example.livetv

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)

        if (ApiConfig.BASE_URL.isBlank() || !ApiConfig.BASE_URL.startsWith("https://")) {
            Toast.makeText(this, "Invalid API base URL", Toast.LENGTH_LONG).show()
            return
        }
        if (ApiConfig.API_KEY.isBlank()) {
            Toast.makeText(this, "API key is not configured", Toast.LENGTH_LONG).show()
            return
        }

        lifecycleScope.launch {
            loadChannels(list)
        }
    }

    private suspend fun loadChannels(list: RecyclerView) {
        try {
            val result = withContext(Dispatchers.IO) {
                requestChannels()
            }

            if (result.httpCode !in 200..299) {
                Toast.makeText(
                    this@MainActivity,
                    "API HTTP ${result.httpCode}: ${result.message}",
                    Toast.LENGTH_LONG
                ).show()
                return
            }

            val raw = result.body.trimStart('\uFEFF', ' ', '\t', '\r', '\n')

            if (raw.isBlank()) {
                Toast.makeText(
                    this@MainActivity,
                    "API returned an empty response",
                    Toast.LENGTH_LONG
                ).show()
                return
            }

            if (!raw.startsWith("{")) {
                val preview = raw.replace("\n", " ").replace("\r", " ").take(140)
                Toast.makeText(
                    this@MainActivity,
                    "Server returned non-JSON. HTTP ${result.httpCode}\n$preview",
                    Toast.LENGTH_LONG
                ).show()
                return
            }

            val gson = GsonBuilder().setLenient().create()
            val type = object : TypeToken<ApiResponse<List<Channel>>>() {}.type
            val apiResponse: ApiResponse<List<Channel>> = gson.fromJson(raw, type)

            if (!apiResponse.success) {
                Toast.makeText(
                    this@MainActivity,
                    apiResponse.message ?: "API request failed",
                    Toast.LENGTH_LONG
                ).show()
                return
            }

            val channels = apiResponse.data.orEmpty()

            if (channels.isEmpty()) {
                Toast.makeText(
                    this@MainActivity,
                    "No active channels found",
                    Toast.LENGTH_LONG
                ).show()
                return
            }

            list.adapter = ChannelAdapter(channels) { channel ->
                startActivity(Intent(this@MainActivity, PlayerActivity::class.java).apply {
                    putExtra("name", channel.name)
                    putExtra("url", channel.stream_url)
                })
            }
        } catch (e: Exception) {
            Toast.makeText(
                this@MainActivity,
                "API error: ${e.message ?: "Connection failed"}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun requestChannels(): ApiResult {
        val encodedKey = URLEncoder.encode(ApiConfig.API_KEY, "UTF-8")
        val url = ApiConfig.BASE_URL.trimEnd('/') + "/api/channels.php?api_key=" + encodedKey

        val request = Request.Builder()
            .url(url)
            .get()
            .header("Accept", "application/json, text/plain, */*")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36")
            .header("Cache-Control", "no-cache")
            .build()

        RetrofitClient.client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            return ApiResult(response.code, body)
        }
    }

    private data class ApiResult(
        val httpCode: Int,
        val body: String
    ) {
        val message: String
            get() {
                return try {
                    val gson = GsonBuilder().setLenient().create()
                    val type = object : TypeToken<ApiResponse<Any>>() {}.type
                    val result: ApiResponse<Any> = gson.fromJson(body, type)
                    result.message ?: "Request failed"
                } catch (_: Exception) {
                    "Request failed"
                }
            }
    }
}
